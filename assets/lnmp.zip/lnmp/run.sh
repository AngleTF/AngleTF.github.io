#!/bin/bash

#:set ff=unix
#:set ff

#mysql-5.7.22 , nginx-1.14.0 , php-7.2.5

dd if=/dev/zero of=/swapfile bs=1k count=2048000
mkswap /swapfile
swapon /swapfile

groupadd -r mysql 
useradd -rg mysql mysql 

groupadd -r nginx
useradd -r -g nginx  nginx

groupadd -r php 
useradd -rg php php 

/bin/cp -f ./my.cnf  /etc/my.cnf

mkdir -p /data/php /data/nginx /data/temp /data/www /data/package /data/boost 

touch /data/temp/mysql_err.log
chmod 777 -R /data/temp

yum -y install cmake make gcc-c++ ncurses-devel perl-Data-Dumper vim wget
yum -y install gcc gcc-c++ automake pcre pcre-devel zlib zlib-devel openssl openssl-devel
yum -y install libmcrypt libmcrypt-devel mhash mhash-devel libxml2 libxml2-devel bzip2 bzip2-devel  autoconf curl-devel libjpeg-devel libpng-devel freetype-devel 

tar zxvf ./mysql-boost-5.7.22.tar.gz -C /data/package 
tar zxvf ./nginx-1.14.0.tar.gz -C /data/package
tar zxvf ./php-7.2.5.tar.gz -C /data/package

cd /data/package/mysql-5.7.22 
cmake -DCMAKE_INSTALL_PREFIX=/data/mysql   -DSYSCONFDIR=/etc -DMYSQL_USER=mysql  -DWITH_MYISAM_STORAGE_ENGINE=1  -DWITH_INNOBASE_STORAGE_ENGINE=1 -DWITH_ARCHIVE_STORAGE_ENGINE=1  -DWITH_MEMORY_STORAGE_ENGINE=1  -DWITH_READLINE=1   -DMYSQL_UNIX_ADDR=/tmp/mysql.sock  -DMYSQL_TCP_PORT=3306  -DENABLED_LOCAL_INFILE=1  -DENABLE_DOWNLOADS=1  -DWITH_PARTITION_STORAGE_ENGINE=1  -DEXTRA_CHARSETS=all  -DDEFAULT_CHARSET=utf8  -DDEFAULT_COLLATION=utf8_general_ci  -DWITH_DEBUG=0  -DMYSQL_MAINTAINER_MOODE=0 -DWITH_BOOST=/data/package/mysql-5.7.22/boost/boost_1_59_0
make && make install 


chown -R mysql:mysql /data/mysql
/data/mysql/bin/mysqld --initialize-insecure --user=mysql --basedir=/data/mysql --datadir=/data/mysql/data
cp /data/mysql/support-files/mysql.server /etc/init.d/mysqld
chmod 777 /etc/init.d/mysqld


echo "export PATH=\$PATH:/data/mysql/bin" >> /etc/profile
source /etc/profile

chkconfig mysqld  on 
chkconfig --add mysqld

service mysqld start





cd /data/package/nginx-1.14.0
./configure --prefix=/data/nginx --sbin-path=/usr/sbin/nginx --conf-path=/etc/nginx/nginx.conf --error-log-path=/data/temp/nginx_error.log --http-log-path=/data/temp/nginx_access.log --user=nginx --group=nginx --with-http_ssl_module --with-http_realip_module --with-http_addition_module --with-http_sub_module --with-http_dav_module --with-http_flv_module --http-client-body-temp-path=/data/temp/client --http-proxy-temp-path=/data/temp/proxy --http-fastcgi-temp-path=/data/temp/fastcgi --with-mail --with-mail_ssl_module --with-pcre
make && make install 

chown -R nginx:nginx /data/nginx
/sbin/nginx




cd /data/package/php-7.2.5
./configure --prefix=/data/php --with-config-file-path=/etc --with-gd --with-iconv --with-zlib --enable-bcmath --enable-shmop --enable-sysvsem --enable-inline-optimization --enable-mbregex --enable-fpm --enable-mbstring --enable-ftp --with-openssl --enable-pcntl --enable-sockets --with-xmlrpc --enable-zip --enable-soap --with-png-dir --with-gettext --with-curl --with-jpeg-dir --with-freetype-dir --with-mysqli --enable-embedded-mysqli --with-pdo-mysql -enable-xml --with-bz2
make && make install

chown -R php:php /data/php
echo "export PATH=\$PATH:/data/php/bin" >> /etc/profile
source /etc/profile

cp /data/package/php-7.2.5/sapi/fpm/init.d.php-fpm /etc/init.d/php-fpm
chmod +x /etc/init.d/php-fpm

cp /data/php/etc/php-fpm.conf.default /data/php/etc/php-fpm.conf

cp /data/php/etc/php-fpm.d/www.conf.default /data/php/etc/php-fpm.d/www.conf
cp /data/package/php-7.2.5/php.ini-production /etc/php.ini

service php-fpm start


swapoff /swapfile
rm -fr /swapfile

php -v

ls -hl /data
source /etc/profile
